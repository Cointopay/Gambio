<?php
define('MODULE_PAYMENT_COINTOPAY_TEXT_TITLE', 'Cointopay International');
define('MODULE_PAYMENT_COINTOPAY_TEXT_DESCRIPTION', 'Cointopay International');
define('MODULE_PAYMENT_COINTOPAY_TEXT_CHECKOUT', 'Cointopay International');
define('MODULE_PAYMENT_COINTOPAY_ALIAS_TITLE', 'Titel');
define('MODULE_PAYMENT_COINTOPAY_STATUS_TITLE', 'Aktiv');
define('MODULE_PAYMENT_COINTOPAY_ALLOWED_TITLE' , 'Erlaubte Zonen');
define('MODULE_PAYMENT_COINTOPAY_ALLOWED_DESC' , 'Geben Sie erlaubte Zonen ein (e.g. AT,DE)');
define('MODULE_PAYMENT_COINTOPAY_MERCHANT_ID_TITLE', 'Händler-ID');
define('MODULE_PAYMENT_COINTOPAY_SECURITY_CODE_TITLE', 'Sicherheitscode');
define('MODULE_PAYMENT_COINTOPAY_PAID_STATUS_ID_TITLE', 'Cointopay bezahlte Status');
define('MODULE_PAYMENT_COINTOPAY_FAILED_STATUS_ID_TITLE', 'Cointopay-Status fehlgeschlagen');
define('MODULE_PAYMENT_COINTOPAY_PAIDNOTENOUGH_STATUS_ID_TITLE', 'Cointopay zahlte nicht genug');
